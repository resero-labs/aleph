import io
import csv
import logging
from normality import safe_filename, stringify

from ingestors.util import join_path

log = logging.getLogger(__name__)


class CSVEmitterSupport():
    """Generate a CSV file from a generator of rows."""

    def csv_child_iter(self, iter, name):
        out_name = safe_filename(name,
                                 default='sheet.csv',
                                 extension='csv')
        out_path = join_path(self.work_path, out_name)
        row_count = 0
        with io.open(out_path, 'w', newline='', encoding='utf-8') as fh:
            writer = csv.writer(fh, quoting=csv.QUOTE_ALL)
            for row in iter:
                writer.writerow(row)
                row_count += 1

        name = stringify(name) or 'sheet'
        if row_count == 0:
            log.warning("Skip [%s]: no rows", name)
            return

        log.info("Generated [%s]: %s, %s rows", name, out_name, row_count)

        child_id = join_path(self.result.id, name)
        self.manager.handle_child(self.result, out_path,
                                  id=child_id,
                                  title=name,
                                  file_name=out_name,
                                  mime_type='text/csv')
