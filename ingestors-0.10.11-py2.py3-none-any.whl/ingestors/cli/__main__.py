import sys
import json
import logging
import click
import boto3
import re
import os

from datetime import date, datetime

def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    raise TypeError ("Type %s not serializable" % type(obj))

from ingestors.cli import cli
from ingestors import Manager


logger = logging.getLogger(__name__)


@click.group()
def enhanced_cli():
    logging.basicConfig(level=logging.INFO)


@enhanced_cli.command()
@click.argument('files', nargs=-1)
def ingest_file(files):
    #if sys.argv[1:]:
    #    cli(''.join(sys.argv[1:]))
    logger.info('Ingesting from files: {}'.format(files))
    cli(''.join(files))


@enhanced_cli.command()
@click.argument('bucket_name')
@click.option('--s3-path', default='')
@click.option('--result-bucket', default=None)
@click.option('--result-path', default=None)
def ingest_s3(bucket_name, s3_path, result_bucket, result_path):
    logger.info('Ingesting from s3: {}'.format(s3_path))

    manager = Manager({})
    result_bucket = result_bucket or bucket_name

    resource = boto3.resource('s3', region_name='us-west-2')
    bucket = resource.Bucket(bucket_name)

    root_dir = '/tmp/ingest'
    os.makedirs(root_dir, exist_ok=True)

    for item in bucket.objects.filter(Prefix = s3_path):
        if item.size <= 0:
            continue

        full_path, filename = os.path.split(item.key)
        download_name = '{}/{}'.format(root_dir, filename)
        bucket.download_file(item.key, download_name)

        result = manager.ingest(download_name)
        if result_path is not None:
            with open('/tmp/result.json', 'w', encoding='utf-8') as f:
                json.dump(result.to_dict(), f, ensure_ascii=False, default=json_serial)
            upload_key = os.path.join(result_path, full_path, filename) + '.json'
            resource.meta.client.upload_file('/tmp/result.json', result_bucket, upload_key)
            os.remove('/tmp/result.json')

        logger.debug(result.to_dict())
        os.remove(download_name)


if __name__ == '__main__':
    enhanced_cli()
    #logging.basicConfig(level='DEBUG')

    #if sys.argv[1:]:
    #    cli(''.join(sys.argv[1:]))
    #else:
    #    print('No file provided.')
    #    sys.exit(1)

