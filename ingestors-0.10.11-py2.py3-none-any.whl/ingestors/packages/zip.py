import logging
import zipfile

from ingestors.base import Ingestor
from ingestors.support.package import PackageSupport
from ingestors.exc import ProcessingException

log = logging.getLogger(__name__)


class ZipIngestor(PackageSupport, Ingestor):
    MIME_TYPES = [
        'application/zip',
        'application/x-zip',
        'multipart/x-zip',
        'application/zip-compressed',
        'application/x-zip-compressed',
    ]
    EXTENSIONS = [
        'zip'
    ]
    SCORE = 3

    def unpack(self, file_path, temp_dir):
        try:
            with zipfile.ZipFile(file_path) as zf:
                names = zf.namelist()
                encoding = self.detect_list_encoding(names)
                log.debug('Detected filename encoding: %s', encoding)
                for name in names:
                    try:
                        fh = zf.open(name)
                        self.extract_member(temp_dir, name, fh,
                                            encoding=encoding)
                    except Exception as ex:
                        # TODO: should this be a fatal error?
                        log.debug("Failed to unpack [%r]: %s", name, ex)
        except (zipfile.BadZipfile, OSError) as bzfe:
            raise ProcessingException('Invalid ZIP file: %s' % bzfe)

    @classmethod
    def match(cls, file_path, result=None):
        if zipfile.is_zipfile(file_path):
            return cls.SCORE
        return super(ZipIngestor, cls).match(file_path, result=result)
