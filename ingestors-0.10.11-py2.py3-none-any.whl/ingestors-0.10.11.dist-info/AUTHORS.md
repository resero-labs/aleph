# Credits

* Stas Sușcov <stas@nerd.ro>
* Friedrich Lindenberg <friedrich@pudo.org>
